package Activitiy3;

public class number9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Not clear whwat is notes in given amount
		

	}

}
