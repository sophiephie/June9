package Activitiy3;

public class number22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//question not matching with cases and table
	}

}
