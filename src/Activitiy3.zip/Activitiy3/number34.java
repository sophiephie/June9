package Activitiy3;

public class number34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//unclear instructions, what are the functionalities of a simple calculator?

	}

}
