package Activitiy3;

public class number32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//not sure how to count the number of digits
	}

}
